package com.aaa.Test;

import com.aaa.service.TestService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    public static void main(String[] args) {
        //实例化spring容器
        ApplicationContext act = new ClassPathXmlApplicationContext("spring.xml");
        //通过id获得bean
        TestService service = (TestService) act.getBean("testServiceImpl");
        service.add();
    }
}
