package com.aaa.service;

public interface TestService {
    public void add();
}
