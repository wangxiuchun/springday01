package com.aaa.service;

import com.aaa.dao.TestDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestServiceImpl implements TestService {
    @Autowired
    private TestDao dao;
    public void add() {
        dao.add();
    }
    //设置注入
//    public void setDao(TestDao dao) {
////        this.dao = dao;
////    }

    //构造注入
    //依赖对象作为构造器的一个参数
//    public TestServiceImpl(TestDao dao) {
//        this.dao = dao;
//    }

//    //自动注入
        public void setDao(TestDao dao) {
        this.dao = dao;
    }
}
