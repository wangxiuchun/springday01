package com.aaa.dao;

public interface TestDao {
    public void add();
}
