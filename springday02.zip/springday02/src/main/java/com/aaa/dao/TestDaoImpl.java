package com.aaa.dao;

import org.springframework.stereotype.Repository;

@Repository
public class TestDaoImpl implements TestDao {
    public void add() {
        System.out.println("持久层：已连接");
    }
}
